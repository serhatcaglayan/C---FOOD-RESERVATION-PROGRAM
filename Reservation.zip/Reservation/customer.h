#ifndef CUSTOMER_H_INCLUDED
#define CUSTOMER_H_INCLUDED
#include "common.h"
Food checkFoodId(char *foodsTxt, int foodId);
void newOrder(char tableId[], int foodId, int amount);
void updateQuantity(char tableId[], int foodId, int newAmount);
void cancelOrder(char tableId[], int foodId);
void payBill(char tableId[]);
#endif // CUSTOMER_H_INCLUDED
