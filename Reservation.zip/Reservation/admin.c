#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdbool.h>
#include "admin.h"
extern char *foodsTxt;
extern char *ordersTxt;
extern char *closedOrdersTxt;
extern char *takenOrdersTxt;
extern char *logTtxt;


void CreateTable(char tableID[])
{
    DIR *dir;
    if(!(CheckID(tableID)))
    {
        mkdir(tableID,S_IRUSR|S_IWUSR|S_IXUSR);
        strcat(tableID,"//");
        strcat(tableID,ordersTxt);
        FILE *file=fopen(tableID,"ab+");
        fclose(file);

        printf("---Table created successfully\n");
        char txt[250];
        sprintf(txt,"Table %s created successfully...",tableID);
        writeToLogFile(txt);
    }
    else
    {
        printf("---The table ID already given!!! Try another ID.\n");
    }
}

void DeleteTable(char tableID[])
{
    if(CheckID(tableID)==true)
    {
        char temp[250];
        strcpy(temp,tableID);
        strcat(temp,"//");
        strcat(temp,ordersTxt);
        remove(temp);
        rmdir(tableID);
        printf("---Table deleted successfully\n");
        char txt[250];
        sprintf(txt,"--Table %s deleted successfully...",txt);
        writeToLogFile(txt);
    }
    else
    {
        printf("---The table ID could not found!!!");
    }
}

void CheckNewOrder()
{
	FILE *file = fopen(takenOrdersTxt,"rb+");
    takenOrder t;

	fread(&t,sizeof(takenOrder),1,file);
	if(!feof(file)){
	int choice;

	printf("Food ID : %s\n",t.tableId);
	printf("Food name : %d\n",t.f.id);
	printf("Food name : %s\n",t.f.name);
	printf("Food fee : %.2f\n",(t.f.fee * t.quantity));
	printf("Is confirmed : %s\n",t.isConfirmed ? "yes" :"no");
	printf("Is active : %s\n",t.isActive);
	printf("Confirm Order?\n");
	printf("Yes : 1\n");
	printf("No : 0\n");
	printf("Warning: Unconfirmed orders will be canceled!!!\n");
	printf("Warning: Approved orders are assigned to the relevant table !!!");
	scanf("%d",&choice);

	if(choice == 1){
		char name[250];
		strcpy(name,t.tableId);
		strcat(name,"//");
		strcat(name,ordersTxt);
		t.isConfirmed = true;
		FILE *file1 = fopen(name,"ab+");
		fwrite(&t,sizeof(takenOrder),1,file1);
		fclose(file1);
	}
	fclose(file);

	file = fopen(takenOrdersTxt, "wb+");
	fclose(file);
	}
	else
    {
        printf("---No orders....\n");
	}
}

void ShowAllInvoices()
{
    FILE *file=fopen(closedOrdersTxt,"r+");
    if(file == NULL)
    {
        printf("---No invoices found!!!\n");
    }
    else
    {
        printf("All invoices information : \n");
        float fee;
        while(fscanf(file,"%f",&fee)==1)
        {
            printf("TOTAL FEE : %2f\n",fee);
        }
        fclose(file);
    }
}

void UpdateFood(int foodID, float newFee)
{
    FILE *file=fopen(foodsTxt,"rb+");
    bool isUpdate=false;
    Food f;

    while(fread(&f,sizeof(Food),1,file)==1)
    {
        if(foodID==f.id)
        {
            f.fee=newFee;
            fseek(file,-sizeof(Food),SEEK_CUR);
            fwrite(&f,sizeof(Food),1,file);+

            isUpdate=true;
            break;
        }
    }

    fclose(file);

    if(isUpdate==true)
    {
        printf("---Food is updated.\n");

        char text[250];
        sprintf(text,"Food %d is updated successfully.\n",foodID);
        writeToLogFile(text);
    }
    else
    {
        printf("---There is no food with the given ID.\n");
    }

}

bool CheckID(char tableID[])
{
    bool checkI=false;
    DIR *dir;
    char  cwd[50];
    getcwd(cwd, 50);
    dir = opendir(cwd);
    struct dirent *dirp;
    while( (dirp = readdir(dir)) !=NULL)
    {
        if((strcmp(dirp->d_name,".") != 0) &&strcmp(dirp->d_name,"..") != 0 )
        {
            struct stat info;
            stat(dirp->d_name,&info);
            if((strcmp(dirp->d_name,tableID)==0)&&S_ISDIR(info.st_mode))
            {
                  checkI=true;
            }
        }
    }
    closedir(dir);
    return checkI;
}


