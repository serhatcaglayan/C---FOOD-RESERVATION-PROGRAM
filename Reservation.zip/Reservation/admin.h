#ifndef ADMIN_H_INCLUDED
#define ADMIN_H_INCLUDED
#include "common.h"
#include <stdbool.h>
void CreateTable(char tableID[]);
void DeleteTable(char tableID[]);
void CheckNewOrder();
void ShowAllInvoices();
void UpdateFood(int foodID, float newFee);
bool CheckID(char tableID[]);
#endif // ADMIN_H_INCLUDED
